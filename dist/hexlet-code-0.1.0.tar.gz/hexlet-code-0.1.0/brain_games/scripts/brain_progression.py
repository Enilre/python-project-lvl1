"""Script for Brain progression."""
#!/usr/bin/env python
from brain_games.games.question_answer_prog import question_answer


def main():
    """Run Script."""
    question_answer()


if __name__ == '__main__':
    main()
