"""Script for GCD game."""
#!/usr/bin/env python
from brain_games.games.question_answer_gcd import question_answer


def main():
    """Run script."""
    question_answer()


if __name__ == '__main__':
    main()
