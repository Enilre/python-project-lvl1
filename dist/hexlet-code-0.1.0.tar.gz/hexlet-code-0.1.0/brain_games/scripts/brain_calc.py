"""Script for the second Game - Brain calc."""
#!/usr/bin/env python
from brain_games.games.question_answer_calc import question_answer


def main():
    """Run script for question and answer."""
    question_answer()


if __name__ == '__main__':
    main()
